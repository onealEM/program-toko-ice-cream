package eskrim;

import java.awt.HeadlessException;
import java.sql.Connection;
import javax.swing.table.DefaultTableModel;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author Rezieq
 */
public class data extends javax.swing.JFrame {

    private void kosong_kolom(){
        txtkode.setText(null);
        txtmerk.setText(null);
        txtpartai.setText(null);
        txtstok.setText(null);
    }
    
    private void tampil_data(){
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("No");
        model.addColumn("Kode Es");
        model.addColumn("Merk");
        model.addColumn("Harga");
        model.addColumn("Stok");
    
        try{
            int no = 1;
            String sql = "SELECT * FROM eskrim";
            java.sql.Connection conn = (Connection)konfigdatabase.configDB();
            java.sql.Statement stm = conn.createStatement();
            java.sql.ResultSet res = stm.executeQuery(sql);
            
            while(res.next()){
                model.addRow(new Object[]{no++, res.getString(1),
                                                res.getString(2),
                                                res.getString(3),
                                                res.getString(4)});
            }
            tabel.setModel(model);
            
        }catch(SQLException e){
            System.out.println("Eror : " + e.getMessage());
        }
    }
    
    public data() {
        initComponents();
        tampil_data();
        kosong_kolom();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        txtkode = new javax.swing.JTextField();
        txtmerk = new javax.swing.JTextField();
        txtpartai = new javax.swing.JTextField();
        txtstok = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabel = new javax.swing.JTable();
        tbBaru = new javax.swing.JButton();
        tbTambah = new javax.swing.JButton();
        tbPerbarui = new javax.swing.JButton();
        tbHapus = new javax.swing.JButton();
        tbKeluar = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setMaximumSize(new java.awt.Dimension(891, 450));
        jPanel1.setMinimumSize(new java.awt.Dimension(891, 450));
        jPanel1.setPreferredSize(new java.awt.Dimension(891, 450));

        jPanel3.setBackground(new java.awt.Color(204, 255, 255));
        jPanel3.setMinimumSize(new java.awt.Dimension(891, 450));
        jPanel3.setPreferredSize(new java.awt.Dimension(891, 450));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtkode.setBackground(new java.awt.Color(102, 51, 0));
        txtkode.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        txtkode.setForeground(new java.awt.Color(255, 255, 255));
        txtkode.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtkodeActionPerformed(evt);
            }
        });
        jPanel3.add(txtkode, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 120, 380, 40));

        txtmerk.setBackground(new java.awt.Color(102, 51, 0));
        txtmerk.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        txtmerk.setForeground(new java.awt.Color(255, 255, 255));
        jPanel3.add(txtmerk, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 190, 380, 40));

        txtpartai.setBackground(new java.awt.Color(102, 51, 0));
        txtpartai.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        txtpartai.setForeground(new java.awt.Color(255, 255, 255));
        jPanel3.add(txtpartai, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 260, 380, 40));

        txtstok.setBackground(new java.awt.Color(102, 51, 0));
        txtstok.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        txtstok.setForeground(new java.awt.Color(255, 255, 255));
        jPanel3.add(txtstok, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 330, 380, 40));

        tabel.setBackground(new java.awt.Color(255, 204, 102));
        tabel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        tabel.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tabel.setToolTipText("");
        tabel.setAlignmentX(2.0F);
        tabel.setAlignmentY(2.0F);
        tabel.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_ALL_COLUMNS);
        tabel.setEditingColumn(1);
        tabel.setEditingRow(1);
        tabel.setRequestFocusEnabled(false);
        tabel.setRowMargin(5);
        tabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tabelMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tabel);

        jPanel3.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 410, 750, 110));

        tbBaru.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        tbBaru.setText("Reset");
        tbBaru.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tbBaruActionPerformed(evt);
            }
        });
        jPanel3.add(tbBaru, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 360, 100, 30));

        tbTambah.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        tbTambah.setText("Tambah");
        tbTambah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tbTambahActionPerformed(evt);
            }
        });
        jPanel3.add(tbTambah, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 120, 100, -1));

        tbPerbarui.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        tbPerbarui.setText("Perbarui");
        tbPerbarui.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tbPerbaruiActionPerformed(evt);
            }
        });
        jPanel3.add(tbPerbarui, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 180, 100, -1));

        tbHapus.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        tbHapus.setText("Hapus");
        tbHapus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tbHapusActionPerformed(evt);
            }
        });
        jPanel3.add(tbHapus, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 240, 100, -1));

        tbKeluar.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        tbKeluar.setText("Keluar");
        tbKeluar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tbKeluarActionPerformed(evt);
            }
        });
        jPanel3.add(tbKeluar, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 300, 100, -1));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gambar/TOKO ES KRIM ONILA.png"))); // NOI18N
        jLabel1.setText("jLabel1");
        jPanel3.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 990, 540));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 850, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(172, 172, 172))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 542, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 854, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 6, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 542, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void tbKeluarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tbKeluarActionPerformed
        System.exit(0);
    }//GEN-LAST:event_tbKeluarActionPerformed

    private void tbHapusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tbHapusActionPerformed
        try{
            String sql = "DELETE FROM eskrim WHERE kode_es='"+txtkode.getText()+"'";
            java.sql.Connection conn = (Connection)konfigdatabase.configDB();
            java.sql.PreparedStatement pstm = conn.prepareStatement(sql);
            pstm.execute();
            JOptionPane.showMessageDialog(null, "Data es krim berhasil dihapus");
        }catch(HeadlessException | SQLException e){
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
        tampil_data();
        kosong_kolom();
    }//GEN-LAST:event_tbHapusActionPerformed

    private void tbPerbaruiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tbPerbaruiActionPerformed
        try{
            String sql = "UPDATE eskrim SET kode_es='"+txtkode.getText()+"',merk='"
                                                         +txtmerk.getText()+"',harga='"
                                                         +txtpartai.getText()+"',stok='"
                                                         +txtstok.getText()+"' WHERE kode_es='"+txtkode.getText()+"'";
            java.sql.Connection conn = (Connection)konfigdatabase.configDB();
            java.sql.PreparedStatement pstm = conn.prepareStatement(sql);
//            sql = String.format(sql, no, nama, partai, kabinet, periode);
            pstm.execute();
            JOptionPane.showMessageDialog(null, "Data es krim berhasil diperbarui");
            kosong_kolom();
        }catch(HeadlessException | SQLException e){
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
        tampil_data();
//        kosong_kolom();
    }//GEN-LAST:event_tbPerbaruiActionPerformed

    private void tbTambahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tbTambahActionPerformed
        try{
            String sql = "INSERT INTO eskrim VALUES ('"+txtkode.getText()+"','"
                                                           +txtmerk.getText()+"','"
                                                           +txtpartai.getText()+"','"
                                                           +txtstok.getText()+"',111)";
            java.sql.Connection conn = (Connection)konfigdatabase.configDB();
            java.sql.PreparedStatement pstm = conn.prepareStatement(sql);
            pstm.execute();
            JOptionPane.showMessageDialog(null, "Data es krim berhasil disimpan");
        }catch(HeadlessException | SQLException e){
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
        tampil_data();
        kosong_kolom();
    }//GEN-LAST:event_tbTambahActionPerformed

    private void tbBaruActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tbBaruActionPerformed
        kosong_kolom();
    }//GEN-LAST:event_tbBaruActionPerformed

    private void tabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tabelMouseClicked
        int baris = tabel.rowAtPoint(evt.getPoint());
        String kode = tabel.getValueAt(baris, 1).toString();
        txtkode.setText(kode);

        String merk = tabel.getValueAt(baris, 2).toString();
        txtmerk.setText(merk);

        String harga = tabel.getValueAt(baris, 3).toString();
        txtpartai.setText(harga);

        String stok = tabel.getValueAt(baris, 4).toString();
        txtstok.setText(stok); 
    }//GEN-LAST:event_tabelMouseClicked

    private void txtkodeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtkodeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtkodeActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(data.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(data.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(data.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(data.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new data().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tabel;
    private javax.swing.JButton tbBaru;
    private javax.swing.JButton tbHapus;
    private javax.swing.JButton tbKeluar;
    private javax.swing.JButton tbPerbarui;
    private javax.swing.JButton tbTambah;
    private javax.swing.JTextField txtkode;
    private javax.swing.JTextField txtmerk;
    private javax.swing.JTextField txtpartai;
    private javax.swing.JTextField txtstok;
    // End of variables declaration//GEN-END:variables
}
